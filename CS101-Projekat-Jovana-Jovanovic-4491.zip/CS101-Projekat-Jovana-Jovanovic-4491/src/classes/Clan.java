package classes;

import exceptions.BrojNijeValidanException;
import exceptions.InvalidOsobaException;
import exceptions.NazivNijeValidanException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author HP
 */
public class Clan extends Osoba {

    private String brojTelefona;

    /**
     * Prazan konstruktor
     */
    public Clan() {
    }

    /**
     * Preopterecen konstruktor koji prima sve argumente kao atribute
     *
     */
    public Clan(String ime, String prezime, String brojGodina, String jmbg, String brojTelefona) throws InvalidOsobaException {
        super(ime, prezime, brojGodina, jmbg);
        this.brojTelefona = brojTelefona;
    }

    /**
     * Konstruktor kopije
     */
    public Clan(Clan c) throws InvalidOsobaException {
        super(c.getIme(), c.getPrezime(), c.getBrojGodina(), c.getJmbg());
        this.brojTelefona = c.brojTelefona;
    }

    /**
     * get i set metode
     *
     */
    public String getBrojTelefona() {
        return brojTelefona;
    }

    public void setBrojTelefona(String brojTelefona) throws BrojNijeValidanException {
        if (util.Util.sadrziSamoBrojeve(brojTelefona)) {
            this.brojTelefona = brojTelefona;
        } else {
            throw new BrojNijeValidanException("Broj Telefona mora sadržati samo cifre!");
        }
    }

    /**
     * metoda toString
     *
     */
    @Override
    public String toString() {
        return "Član --> " + "\n"
                + super.toString() + "\n"
                + "Broj telefona: " + brojTelefona + "\n";

    }

}
