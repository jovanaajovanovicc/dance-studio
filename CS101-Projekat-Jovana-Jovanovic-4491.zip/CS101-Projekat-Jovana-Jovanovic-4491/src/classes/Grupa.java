package classes;

import enums.Kategorija;
import enums.TipPlesa;
import interfaces.Izracunljiv;

/**
 *
 * @author HP
 */
public class Grupa implements Izracunljiv {

    private String nazivGrupe;
    private int brojClanova;
    private int brojTreningaNedeljno;
    private TipPlesa ples;
    private Kategorija kategorija;
    private Trener trener;
    private double cenaCasa;

    /**
     * Prazan konstruktor
     */
    public Grupa() {
    }

    /**
     * Preopterecen konstruktor
     *
     * @param nazivGrupe naziv
     * @param brojClanova broj clanova
     * @param brojTreningaNedeljno broj treninga nedeljno
     * @param TipPlesa tip plesa
     * @param Kategorija kategorija
     * @param Trener trener
     * @param cenCasa cena
     */
    public Grupa(String nazivGrupe, int brojClanova, int brojTreningaNedeljno, TipPlesa ples, Kategorija kategorija, Trener trener, double cenaCasa) {
        this.nazivGrupe = nazivGrupe;
        this.brojClanova = brojClanova;
        this.brojTreningaNedeljno = brojTreningaNedeljno;
        this.ples = ples;
        this.kategorija = kategorija;
        this.trener = trener;
        this.cenaCasa = cenaCasa;
    }

    /**
     * Konstruktor kopije
     */
    public Grupa(Grupa g) {
        this.nazivGrupe = g.nazivGrupe;
        this.brojClanova = g.brojClanova;
        this.brojTreningaNedeljno = g.brojTreningaNedeljno;
        this.ples = g.ples;
        this.kategorija = g.kategorija;
        this.trener = g.trener;
        this.cenaCasa = g.cenaCasa;
    }

    /**
     * get i set metode
     *
     */
    public String getNazivGrupe() {
        return nazivGrupe;
    }

    public void setNazivGrupe(String nazivGrupe) {
        this.nazivGrupe = nazivGrupe;
    }

    public int getBrojClanova() {
        return brojClanova;
    }

    public void setBrojClanova(int brojClanova) {
        this.brojClanova = brojClanova;
    }

    public int getBrojTreningaNedeljno() {
        return brojTreningaNedeljno;
    }

    public void setBrojTreningaNedeljno(int brojTreningaNedeljno) {
        this.brojTreningaNedeljno = brojTreningaNedeljno;
    }

    public TipPlesa getPles() {
        return ples;
    }

    public void setPles(TipPlesa ples) {
        this.ples = ples;
    }

    public Kategorija getKategorija() {
        return kategorija;
    }

    public void setKategorija(Kategorija kategorija) {
        this.kategorija = kategorija;
    }

    public Trener getTrener() {
        return trener;
    }

    public void setTrener(Trener trener) {
        this.trener = trener;
    }

    public double getCenaCasa() {
        return cenaCasa;
    }

    public void setCenaCasa(double cenaCasa) {
        this.cenaCasa = cenaCasa;
    }

    /**
     * metoda toString
     *
     */
    @Override
    public String toString() {
        return "Grupa --> " + "\n"
                + "Naziv: " + nazivGrupe + "\n"
                + "Broj članova: " + brojClanova + "\n"
                + "Broj treninga nedeljno: " + brojTreningaNedeljno + "\n"
                + "Vrsta plesa: " + ples + "\n"
                + "Kategorija: " + kategorija + "\n"
                + "Trener grupe: " + trener + "\n"
                + "Cena časa: " + cenaCasa + "\n";

    }

    /**
     * metoda iz itnterfejsa Izracunljiv - racuna clanarinu grupe
     *
     * @param brojClanova broj clanova
     * @param brojTreningaNedeljno broj treninga nedeljno
     */
    @Override
    public double racunaj() {
        return cenaCasa * brojTreningaNedeljno * 4;
    }

}
