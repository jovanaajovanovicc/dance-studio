package classes;

import exceptions.BrojNijeValidanException;
import exceptions.InvalidOsobaException;
import exceptions.NazivNijeValidanException;

/**
 *
 * @author HP
 */
public abstract class Osoba {

    private String ime;
    private String prezime;
    private String brojGodina;
    private String jmbg;

    /**
     * Prazan konstruktor
     */
    public Osoba() {
    }

    /**
     * Preopterecen konstruktor koji prima sve atribute kao parametre
     *
     * @param ime ime osobe
     * @param prezime prezime osobe
     * @param brojGodina brojGodina osobe
     * @param jmbg jmbg osobe
     */
    public Osoba(String ime, String prezime, String brojGodina, String jmbg) throws InvalidOsobaException {
        this.setIme(ime);
        this.setPrezime(prezime);
        this.setBrojGodina(brojGodina);
        this.setJmbg(jmbg);
    }

    /**
     * Konstruktor kopije
     */
    public Osoba(Osoba o) throws InvalidOsobaException {
        this.ime = o.ime;
        this.prezime = o.prezime;
        this.brojGodina = o.brojGodina;
        this.jmbg = o.jmbg;
    }

    /**
     * get i set metode
     *
     * @throws NazivNijeValidanException
     * @throws BrojNijeValidanException
     */
    public String getIme() {
        return ime;
    }

    public void setIme(String ime) throws NazivNijeValidanException {
        if (util.Util.validacijaImena(ime) && util.Util.sadrziSamoSlova(ime)) {
            this.ime = ime;
        } else {
            throw new NazivNijeValidanException("Ime nije validno!");
        }
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) throws NazivNijeValidanException {
        if (util.Util.validacijaPrezimena(prezime) && util.Util.sadrziSamoSlova(prezime)) {
            this.prezime = prezime;
        } else {
            throw new NazivNijeValidanException("Prezime nije validno!");
        }
    }

    public String getBrojGodina() {
        return brojGodina;
    }

    public void setBrojGodina(String brojGodina) throws BrojNijeValidanException {
        if (util.Util.sadrziSamoBrojeve(brojGodina)) {
            this.brojGodina = brojGodina;
        } else {
            throw new BrojNijeValidanException("Broj godina mora sadržati samo cifre!");
        }
    }

    public String getJmbg() {
        return jmbg;
    }

    public void setJmbg(String jmbg) throws BrojNijeValidanException {
        if (util.Util.sadrziSamoBrojeve(jmbg) && jmbg.length() == 13) {
            this.jmbg = jmbg;
        } else {
            throw new BrojNijeValidanException("JMBG mora sadržati 13 cifara!");
        }
    }

    /**
     * metoda toString
     *
     */
    @Override
    public String toString() {
        return "Ime: " + this.ime + "\n"
                + "Prezime: " + this.prezime + "\n"
                + "Broj godina: " + this.brojGodina + "\n"
                + "JMBG: " + this.jmbg + "\n";
    }

}
