package classes;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author HP
 */
public class PlesniKlub {

    private String naziv;
    private String adresa;

    private List<Trener> treneri = new ArrayList<>();
    private List<Grupa> grupe = new ArrayList<>();

    /**
     * Prazan konstruktor
     */
    public PlesniKlub() {
    }

    /**
     * Preopterecen konstruktor koji prima sve argumente kao atribute
     *
     */
    public PlesniKlub(String naziv, String adresa) {
        this.naziv = naziv;
        this.adresa = adresa;

    }

    /**
     * Konstruktor kopije
     */
    public PlesniKlub(PlesniKlub p) {
        this.naziv = p.naziv;
        this.adresa = p.adresa;

    }

    /**
     * get i set metode
     *
     */
    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getAdresa() {
        return adresa;
    }

    public void setAdresa(String adresa) {
        this.adresa = adresa;
    }

    public List<Trener> getTreneri() {
        return treneri;
    }

    public void setTreneri(List<Trener> treneri) {
        this.treneri = treneri;
    }

    public List<Grupa> getGrupe() {
        return grupe;
    }

    public void setGrupe(List<Grupa> grupe) {
        this.grupe = grupe;
    }

    /**
     * metoda toString
     *
     */
    @Override
    public String toString() {
        return "Plesni klub: " + this.naziv + "\n"
                + "Adresa: " + this.adresa + "\n";

    }

}
