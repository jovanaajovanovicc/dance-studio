package classes;

import enums.TipTrenera;
import exceptions.BrojNijeValidanException;
import exceptions.InvalidOsobaException;
import exceptions.NazivNijeValidanException;
import interfaces.Izracunljiv;

/**
 *
 * @author HP
 */
public class Trener extends Osoba implements Comparable<Trener>, Izracunljiv {

    private int brojTreninga;
    private int brojGrupa;
    private TipTrenera tipTrenera;

    /**
     * Prazan konstruktor
     */
    public Trener() {
    }

    /**
     * Preopterecen konstruktor koji prima sve argumente kao atribute
     *
     */
    public Trener(String ime, String prezime, String brojGodina, String jmbg, int brojTreninga, int brojGrupa, TipTrenera tipTrenera) throws InvalidOsobaException {
        super(ime, prezime, brojGodina, jmbg);
        this.brojTreninga = brojTreninga;
        this.brojGrupa = brojGrupa;
        this.tipTrenera = tipTrenera;
    }

    /**
     * Konstruktor kopije
     */
    public Trener(Trener t) throws InvalidOsobaException {
        super(t.getIme(), t.getPrezime(), t.getBrojGodina(), t.getJmbg());
        this.brojTreninga = t.brojTreninga;
        this.brojGrupa = t.brojGrupa;
        this.tipTrenera = t.tipTrenera;
    }

    /**
     * get i set metode
     *
     */
    public int getBrojTreninga() {
        return brojTreninga;
    }

    public void setBrojTreninga(int brojTreninga) {
        this.brojTreninga = brojTreninga;
    }

    public int getBrojGrupa() {
        return brojGrupa;
    }

    public void setBrojGrupa(int brojGrupa) {
        this.brojGrupa = brojGrupa;
    }

    public TipTrenera getTipTrenera() {
        return tipTrenera;
    }

    public void setTipTrenera(TipTrenera tipTrenera) {
        this.tipTrenera = tipTrenera;
    }

    /**
     * metoda toString
     *
     */
    @Override
    public String toString() {
        return "Trener --> " + "\n"
                + super.toString() + "\n"
                + "Broj treninga: " + brojTreninga + "\n"
                + "Broj grupa: " + brojGrupa + "\n"
                + "Tip: " + tipTrenera + "\n";
    }

    /**
     * metoda iz interfejsa Comparable - uporedjuje trenere na osovu broja
     * treninga
     *
     * @param Trener t
     *
     */
    public int compareTo(Trener t) {
        if (this.brojTreninga == t.brojTreninga) {
            return 0;
        } else if (this.brojTreninga > t.brojTreninga) {
            return 1;
        } else {
            return -1;
        }
    }

    /**
     * metoda iz interfejsa Izracunljiv - racuna platu trenera
     *
     * @param brojGrupa broj grupa
     * @param brojTreninga broj treninga
     */
    @Override
    public double racunaj() {
        return brojGrupa * brojTreninga * 900;
    }

}
