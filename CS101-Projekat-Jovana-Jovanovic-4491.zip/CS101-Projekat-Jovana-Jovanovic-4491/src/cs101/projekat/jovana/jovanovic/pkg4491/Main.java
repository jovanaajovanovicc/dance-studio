package cs101.projekat.jovana.jovanovic.pkg4491;

/**
 *
 * @author HP
 */
import classes.*;
import enums.Kategorija;
import enums.TipPlesa;
import enums.TipTrenera;
import exceptions.InvalidOsobaException;
import static files.ReadFile.listaTrenera;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import util.Menu;
import static util.Menu.menu;
import static util.Metode.noviClan;

public class Main {

    /**
     * main
     *
     * @param args the command line arguments
     * @throws InvalidOsobaException
     * @throwsIOException
     */
    public static void main(String[] args) throws InvalidOsobaException, IOException {

        System.out.println("▌│█║▌║▌║ LET'S DANCE ║▌║▌║█│▌");

        PlesniKlub pk = new PlesniKlub("Fҽɳιx ԃαɳƈҽ ʂƚυԃισ", "ŋıƙơƖɛ ℘ąšıćą 25");
        System.out.println(pk);

        List<Trener> treneri = new ArrayList<>();
        treneri = listaTrenera();
        pk.setTreneri(treneri);

        menu(pk);
        System.out.println(" ");

    }

}
