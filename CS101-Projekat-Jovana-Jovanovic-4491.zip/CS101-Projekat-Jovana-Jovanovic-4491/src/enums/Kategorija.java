package enums;

/**
 *
 * @author HP
 */
public enum Kategorija {
    DECA, JUNIORI, ODRASLI;
}
