package enums;

/**
 *
 * @author HP
 */
public enum TipPlesa {
    HIPHOP, DISCODANCE, BREAKDANCE;
}
