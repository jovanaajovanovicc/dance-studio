package enums;

/**
 *
 * @author HP
 */
public enum TipTrenera {
    HIPHOPER, DISCODANCER, BREAKDANCER;
}
