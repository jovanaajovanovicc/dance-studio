package exceptions;

/**
 *
 * @author HP
 */
public class BrojNijeValidanException extends InvalidOsobaException {

    public BrojNijeValidanException(String string) {
        super(string);
    }

}
