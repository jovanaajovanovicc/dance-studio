package exceptions;

/**
 *
 * @author HP
 */
public abstract class InvalidOsobaException extends Exception {

    public InvalidOsobaException(String string) {
        super(string);
    }

}
