package exceptions;

/**
 *
 * @author HP
 */
public class NazivNijeValidanException extends InvalidOsobaException {

    public NazivNijeValidanException(String string) {
        super(string);
    }

}
