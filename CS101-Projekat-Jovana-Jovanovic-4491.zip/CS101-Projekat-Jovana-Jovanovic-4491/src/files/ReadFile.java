package files;

import classes.Grupa;
import classes.Trener;
import enums.Kategorija;
import enums.TipPlesa;
import enums.TipTrenera;
import exceptions.BrojNijeValidanException;
import exceptions.InvalidOsobaException;
import exceptions.NazivNijeValidanException;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author HP
 */
public class ReadFile {

    /**
     * metoda preko koje se čitaju podaci o trenerima iz fajla
     *
     * @return lista vraća listu trenera
     * @throws FileNotFoundException
     * @throwsIOException
     */
    public static List<Trener> listaTrenera() throws FileNotFoundException, IOException, InvalidOsobaException {

        List<Trener> treneri = new ArrayList<>();
        try {
            BufferedReader bf = new BufferedReader(new FileReader("treneri.txt"));
            String line = null;
            while ((line = bf.readLine()) != null) {
                String niz[] = new String[7];
                niz = line.split(",");
                Trener t = new Trener(niz[0], niz[1], niz[2], niz[3], Integer.parseInt(niz[4]), Integer.parseInt(niz[5]), TipTrenera.valueOf(niz[6]));
                treneri.add(t);
            }
            bf.close();
        } catch (FileNotFoundException ex) {
            System.out.println(ex.getMessage());
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return treneri;
    }

    /**
     * metoda preko koje se čitaju podaci o grupama iz fajla
     *
     * @return lista vraća listu grupa
     * @throws FileNotFoundException
     * @throwsIOException
     */
    public static List<Grupa> listaGrupa() throws FileNotFoundException, IOException, InvalidOsobaException {

        List<Grupa> grupe = new ArrayList<>();
        List<Trener> treneri = listaTrenera();
        int i = 0;
        try {
            BufferedReader bf = new BufferedReader(new FileReader("grupe.txt"));
            String line = null;
            while ((line = bf.readLine()) != null) {
                String niz[] = new String[7];
                niz = line.split(",");
                Trener t = treneri.get(i);
                i++;
                Grupa g = new Grupa(niz[0], Integer.parseInt(niz[1]), Integer.parseInt(niz[2]), TipPlesa.valueOf(niz[3]), Kategorija.valueOf(niz[4]), t, Double.parseDouble(niz[5]));
                grupe.add(g);
            }
            bf.close();
        } catch (FileNotFoundException ex) {
            System.out.println(ex.getMessage());
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

        return grupe;
    }
}
