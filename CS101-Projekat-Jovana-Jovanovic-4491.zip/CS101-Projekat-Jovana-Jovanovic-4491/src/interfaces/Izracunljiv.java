package interfaces;

/**
 *
 * @author HP
 */
public interface Izracunljiv {
    
    double racunaj();
}
