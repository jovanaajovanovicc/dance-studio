/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import classes.Clan;
import classes.Grupa;
import classes.PlesniKlub;
import classes.Trener;
import enums.TipPlesa;
import exceptions.BrojNijeValidanException;
import exceptions.InvalidOsobaException;
import exceptions.NazivNijeValidanException;
import static files.ReadFile.listaGrupa;
import static files.ReadFile.listaTrenera;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import static util.Metode.noviClan;

/**
 *
 * @author HP
 */
public class Menu {

    /**
     * metoda koja prikazuje korisniku meni i daje mogucnost izbora opcija
     *
     *
     */
    public static void menu(PlesniKlub pk) throws IOException, FileNotFoundException, InvalidOsobaException {
        Scanner sc = new Scanner(System.in);

        //meni, dobrodoslica
        System.out.println("--(っ◔◡◔)っ ♥ Dobrodošli u naš plesni klub ♥ (っ◔◡◔)っ--");
        System.out.println("-------*O klubu*-------");
        System.out.println("1 - treneri" + "\n" + "2 - grupe" + "\n" + "3 - seminari" + "\n" + "4 - upis" + "\n");

        while (true) {
            System.out.println("Izaberite jednu od opcija: ");
            System.out.println(" ");
            String izbor = sc.next();

            //prikaz podataka o trenerima
            if (izbor.equals("1")) {
                System.out.println("--> Ovde možete videti podatke o trenerima u klubu!");
                System.out.println(" ");
               // List<Trener> treneri = new ArrayList<>();

                try {     
                    System.out.println(pk.getTreneri());
                    System.out.println("--> Trener sa majvećim brojem treninga je:  " + "\n");
                    System.out.println(Collections.max(listaTrenera()));
                    System.out.println(" ");

                    for (Trener t : listaTrenera()) {
                        System.out.println("-->Plate trenera redom iznose: " + t.racunaj() + " dinara.");
                    }

                    System.out.println("Povratak na meni, da ili ne?");
                    String opcija = sc.nextLine();

                    if (opcija.equals("da")) {
                        System.out.println("Vrati na početak");
                    } else if (opcija.equals("ne")) {
                        System.out.println("▌│█║▌║▌║ KRAJ ║▌║▌║█│▌");
                        break;
                    } else {
                        while (!opcija.equals("da") && !opcija.equals("ne")) {
                            System.out.println("Morate uneti da ili ne!");
                            opcija = sc.nextLine();
                        }
                        if (opcija.equals("da")) {
                            System.out.println("Vrati na početak");
                        } else if (opcija.equals("ne")) {
                            System.out.println("▌│█║▌║▌║ KRAJ ║▌║▌║█│▌");
                            break;
                        }

                    }

                } catch (FileNotFoundException ex) {
                    System.out.println(ex.getMessage());
                }

                //prikaz podataka o grupama
            } else if (izbor.equals("2")) {
                System.out.println("--> Ovde možete videti podatke o grupama u klubu!");
                System.out.println(" ");
                List<Grupa> grupe = new ArrayList<>();
                try {
                    System.out.println(listaGrupa());
                    System.out.println(" ");
                    
                    for (Grupa g : listaGrupa()) {
                        System.out.println("-->Članarine za grupe redom iznose: " + g.racunaj() + " dinara.");
                    }

                    System.out.println("Povratak na meni, da ili ne?");
                    String opcija = sc.nextLine();
                    if (opcija.equals("da")) {
                        System.out.println("Vrati na početak");
                    } else if (opcija.equals("ne")) {
                        System.out.println("▌│█║▌║▌║ KRAJ ║▌║▌║█│▌");
                        break;
                    } else {
                        while (!opcija.equals("da") && !opcija.equals("ne")) {
                            System.out.println("Morate uneti da ili ne!");
                            opcija = sc.nextLine();
                        }
                        if (opcija.equals("da")) {
                            System.out.println("Vrati na početak");

                        } else if (opcija.equals("ne")) {
                            System.out.println("▌│█║▌║▌║ KRAJ ║▌║▌║█│▌");
                            break;
                        }

                    }

                } catch (FileNotFoundException ex) {
                    System.out.println(ex.getMessage());
                }

                //prikaz podataka o seminarima
            } else if (izbor.equals("3")) {
                System.out.println("--> Pogledajte seminare! <--");
                System.out.println("Izaberite opciju:" + "\n" + "1 - show dance " + "\n" + "2 - music video " + "\n");
                String seminar = sc.next();

                //opcije za seminar
                if (seminar.equals("1")) {
                    System.out.println("--> Show dance seminar! <--" + "\n");
                    System.out.println("Petak u 18h sala broj 2 " + "\n" + "Cena seminara: 10€");

                    System.out.println("Povratak na meni, da ili ne?");
                    String opcija = sc.nextLine();
                    if (opcija.equals("da")) {
                        System.out.println("Vrati na početak");
                    } else if (opcija.equals("ne")) {
                        System.out.println("▌│█║▌║▌║ KRAJ ║▌║▌║█│▌j");
                        break;
                    } else {
                        while (!opcija.equals("da") && !opcija.equals("ne")) {
                            System.out.println("Morate uneti da ili ne!");
                            opcija = sc.nextLine();
                        }
                        if (opcija.equals("da")) {
                            System.out.println("Vrati na početak");

                        } else if (opcija.equals("ne")) {
                            System.out.println("▌│█║▌║▌║ KRAJ ║▌║▌║█│▌");
                            break;
                        }

                    }

                } else if (seminar.equals("2")) {
                    System.out.println("--> Music video seminar! <--");
                    System.out.println("Petak u 20h sala broj 1 " + "\n" + "Cena seminara: 15€");

                    System.out.println("Povratak na meni, da ili ne?");
                    String opcija = sc.nextLine();
                    if (opcija.equals("da")) {
                        System.out.println("Vrati na početak");
                    } else if (opcija.equals("ne")) {
                        System.out.println("▌│█║▌║▌║ KRAJ ║▌║▌║█│▌");
                        break;
                    } else {
                        while (!opcija.equals("da") && !opcija.equals("ne")) {
                            System.out.println("Morate uneti da ili ne!");
                            opcija = sc.nextLine();
                        }
                        if (opcija.equals("da")) {
                            System.out.println("Vrati na početak");

                        } else if (opcija.equals("ne")) {
                            System.out.println("▌│█║▌║▌║ KRAJ ║▌║▌║█│▌");
                            break;
                        }

                    }

                }

                //upis u klub 
            } else if (izbor.equals("4")) {
                noviClan();

                System.out.println("Povratak na meni, da ili ne?");
                String opcija = sc.nextLine();
                if (opcija.equals("da")) {
                    System.out.println("Vrati na početak");
                } else if (opcija.equals("ne")) {
                    System.out.println("▌│█║▌║▌║ KRAJ ║▌║▌║█│▌");
                    break;
                } else {
                    while (!opcija.equals("da") && !opcija.equals("ne")) {
                        System.out.println("Morate uneti da ili ne!");
                        opcija = sc.nextLine();
                    }
                    if (opcija.equals("da")) {
                        System.out.println("Vrati na početak");

                    } else if (opcija.equals("ne")) {
                        System.out.println("▌│█║▌║▌║ KRAJ ║▌║▌║█│▌");
                        break;
                    }

                }
            }

        }

    }

}
