package util;

import classes.Clan;
import enums.TipPlesa;
import exceptions.InvalidOsobaException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author HP
 */
public class Metode {

    /**
     * static metoda koja vrši upis novog člana u fajl
     *
     * @param clan 
     */
    public static void addClanToFile(Clan c) {

        try {
            FileOutputStream f = new FileOutputStream(new File("upis.txt"));
            ObjectOutputStream o = new ObjectOutputStream(f);

            o.writeObject(c);
            o.close();
            f.close();

        } catch (IOException ex) {
            ex.getMessage();
        }

    }

    /**
     * void metoda koja pravi novog člana i upisuje ga u fajl
     *
     */
    public static void noviClan() {

        Scanner s = new Scanner(System.in);
        System.out.println("-----------------------------------");
        System.out.println("Upis je u toku!");
        System.out.println(" ");

        while (true) {
            try {
                System.out.println("Unesite ime: ");
                String ime = s.nextLine();

                System.out.println("Unesite prezime: ");
                String prezime = s.nextLine();

                System.out.println("Unesite koliko imate godina: ");
                String brojGodina = s.nextLine();

                System.out.println("Unesite JMBG: ");
                String jmbg = s.nextLine();

                System.out.println("Unesite broj telefona:");
                String brojTelefona = s.nextLine();

                Clan a = new Clan(ime, prezime, brojGodina, jmbg, brojTelefona);

                addClanToFile(a);

                System.out.println(" ");
                System.out.println("Uspešno je popunjena prijava!");
                System.out.println(" ");
                System.out.println("Vaši podaci " + a);
                break;
            } catch (InvalidOsobaException ex) {
                System.out.println(ex.getMessage());
            }

        }
    }

}
