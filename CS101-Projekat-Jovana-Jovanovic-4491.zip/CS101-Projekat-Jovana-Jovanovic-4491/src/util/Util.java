package util;

/**
 *
 * @author HP
 */
public class Util {

    /**
     * boolean metoda koja proverava da li promenljiva sadrzi samo slova
     *
     * @param s
     * @return boolean vraća vrednost true ili false
     */
    public static boolean sadrziSamoSlova(String s) {
        for (char c : s.toCharArray()) {
            if (!Character.isDigit(c)) {
                return true;
            }
        }
        return false;
    }

    /**
     * boolean metoda koja proverava validnost unetog imena
     *
     * @param ime
     * @return boolean vraća true ili false
     */
    public static boolean validacijaImena(String ime) {
        if (ime.length() > 0 && !ime.isEmpty()) {
            return true;
        }
        return false;
    }

    /**
     * boolean metoda koja proverava validnost unetog prezimena
     *
     * @param prezime
     * @return boolean vraća true ili false
     */
    public static boolean validacijaPrezimena(String prezime) {
        if (prezime.length() > 0 && !prezime.isEmpty()) {
            return true;
        }
        return false;
    }

    /**
     * boolean metoda koja proverava da li promenljiva sadrzi samo brojeve
     *
     * @param s
     * @return boolean vraća vrednost true ili false
     */
    public static boolean sadrziSamoBrojeve(String s) {
        for (char c : s.toCharArray()) {
            if (!Character.isDigit(c)) {
                return false;
            }
        }
        return true;
    }

}
